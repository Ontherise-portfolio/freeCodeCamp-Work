#! /bin/bash

# Program to run my other four programs

./questionnaire.sh
./countdown.sh 3
./bingo.sh
./fortune.sh